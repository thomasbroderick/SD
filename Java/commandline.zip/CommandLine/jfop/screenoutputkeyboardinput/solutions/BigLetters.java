
public class BigLetters {
	public static void main(String[] args) {
		System.out.println("W     W    A    PPPPPP");
		System.out.println("W  W  W   A A   P     P");
		System.out.println("W  W  W  A   A  P     P");
		System.out.println("W  W  W A     A PPPPPP");
		System.out.println("W  W  W AAAAAAA P");
		System.out.println("W  W  W A     A P");
		System.out.println(" WW WW  A     A P");
	}
}
